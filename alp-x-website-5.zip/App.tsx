"use client"

import type React from "react"
import { useState, useEffect } from "react"
import Navbar from "./components/Navbar"
import Hero from "./components/Hero"
import ProblemSection from "./components/ProblemSection"
import SolutionSection from "./components/SolutionSection"
import HowItWorks from "./components/HowItWorks"
import BenefitsGrid from "./components/BenefitsGrid"
import ComparisonTable from "./components/ComparisonTable"
import SocialProof from "./components/SocialProof"
import WaitlistForm from "./components/WaitlistForm"
import CTASection from "./components/CTASection"
import Footer from "./components/Footer"
import AboutUs from "./components/AboutUs"
import ProductPage from "./components/ProductPage"
import BlogPage from "./components/BlogPage"

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<"home" | "product" | "about" | "blog">("home")

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [currentPage])

  const renderContent = () => {
    switch (currentPage) {
      case "product":
        return <ProductPage />
      case "about":
        return <AboutUs />
      case "blog":
        return <BlogPage />
      default:
        return (
          <>
            <Hero />
            <ProblemSection />
            <SolutionSection />
            <HowItWorks />
            <BenefitsGrid />
            <ComparisonTable />
            <SocialProof />
            <WaitlistForm />
          </>
        )
    }
  }

  return (
    <div className="min-h-screen bg-white text-slate-900 overflow-x-hidden">
      <Navbar onPageChange={setCurrentPage} currentPage={currentPage} />
      <main>
        {renderContent()}
        <CTASection />
      </main>
      <Footer onPageChange={setCurrentPage} />
    </div>
  )
}

export default App
