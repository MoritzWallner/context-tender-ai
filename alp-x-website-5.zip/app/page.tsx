"use client"

import { useState, useEffect } from "react"
import Navbar from "@/components/Navbar"
import ProblemSection from "@/components/ProblemSection"
import Hero from "@/components/Hero"
import ComparisonTable from "@/components/ComparisonTable"
import TenderMatchFeatures from "@/components/TenderMatchFeatures"
import CompanyMatchFeatures from "@/components/CompanyMatchFeatures"
import IndustryFeatures from "@/components/IndustryFeatures"
import TenderMatchDemo from "@/components/TenderMatchDemo"
import Footer from "@/components/Footer"
import AboutUs from "@/components/AboutUs"
import ProductPage from "@/components/ProductPage"
import BlogPage from "@/components/BlogPage"
import FooterImage from "@/components/FooterImage"

export default function Page() {
  const [currentPage, setCurrentPage] = useState<"home" | "product" | "about" | "blog">("home")

  // Scroll to top on page change
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [currentPage])

  const renderContent = () => {
    switch (currentPage) {
      case "product":
        return <ProductPage />
      case "about":
        return <AboutUs />
      case "blog":
        return <BlogPage />
      default:
        return (
          <>
            <Hero />
            <ProblemSection />
            <ComparisonTable />
            <TenderMatchFeatures />
            <CompanyMatchFeatures />
            <IndustryFeatures />
          </>
        )
    }
  }

  return (
    <div className="min-h-screen bg-white text-slate-900 overflow-x-hidden">
      <Navbar onPageChange={setCurrentPage} currentPage={currentPage} />
      <main>
        {renderContent()}
        <TenderMatchDemo />
      </main>
      <Footer onPageChange={setCurrentPage} />
      <FooterImage />
    </div>
  )
}
