import type React from "react"
import Navbar from "@/components/Navbar"
import Footer from "@/components/Footer"
import FramedCard from "@/components/FramedCard"

const ProductFeatureSection: React.FC<{
  id: string
  title: string
  subtitle: string
  description: string
  highlights: { label: string; value: string }[]
  benefits: string[]
  image?: string
  reversed?: boolean
}> = ({ id, title, subtitle, description, highlights, benefits, image, reversed = false }) => (
  <section id={id} className="py-24 scroll-mt-20">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <FramedCard variant="default">
        <div className={`grid lg:grid-cols-2 gap-12 items-center ${reversed ? "lg:flex-row-reverse" : ""}`}>
          {/* Content Side */}
          <div className={reversed ? "lg:order-2" : ""}>
            <span className="text-blue-600 font-bold tracking-[0.3em] uppercase text-[10px] mb-4 block">Feature</span>
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6 tracking-tight">{title}</h2>
            <p className="text-xl text-slate-600 mb-8 leading-relaxed">{subtitle}</p>
            <p className="text-slate-500 leading-relaxed mb-8">{description}</p>

            {/* Highlights */}
            {highlights.length > 0 && (
              <div className="grid grid-cols-2 gap-4 mb-8">
                {highlights.map((highlight, idx) => (
                  <div key={idx} className="bg-slate-50 rounded-xl p-4">
                    <div className="text-2xl font-bold text-blue-600 mb-1">{highlight.value}</div>
                    <div className="text-sm text-slate-600 font-medium">{highlight.label}</div>
                  </div>
                ))}
              </div>
            )}

            {/* Benefits */}
            {benefits.length > 0 && (
              <div className="space-y-3">
                {benefits.map((benefit, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <svg
                      className="w-6 h-6 text-blue-600 flex-shrink-0 mt-0.5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span className="text-slate-600 leading-relaxed">{benefit}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Image Side */}
          <div className={reversed ? "lg:order-1" : ""}>
            <div className="aspect-[4/3] bg-slate-50 rounded-2xl overflow-hidden border border-slate-100 shadow-xl">
              {image && <img src={image || "/placeholder.svg"} alt={title} className="w-full h-full object-cover" />}
            </div>
          </div>
        </div>
      </FramedCard>
    </div>
  </section>
)

export default function ProductsPage() {
  return (
    <main className="min-h-screen bg-white">
      <Navbar />

      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-gradient-to-b from-slate-50 to-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="text-blue-600 font-bold tracking-[0.3em] uppercase text-[10px] mb-4 block">
            Product Features
          </span>
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6 tracking-tight">
            Everything You Need to Win European Tenders
          </h1>
          <p className="text-xl text-slate-600 leading-relaxed max-w-3xl mx-auto">
            From intelligent discovery across 2,000+ portals to AI-powered partner matching. One platform, complete
            control, maximum results.
          </p>
        </div>
      </section>

      {/* tender.match Features */}
      <ProductFeatureSection
        id="portal-coverage"
        title="2,000+ Portal Coverage"
        subtitle="Search All of Europe. Instantly."
        description="European procurement is fragmented across 2,000+ platforms in 27 countries. Our AI aggregates every major portal into one unified dashboard, monitors them 24/7, and delivers opportunities in 40+ languages—automatically translated and analyzed. One profile. All markets. Zero manual browsing."
        highlights={[
          { label: "Procurement Portals", value: "2,000+" },
          { label: "EU Countries Covered", value: "27+" },
          { label: "Languages Supported", value: "40+" },
          { label: "Annual Volume", value: "€2.5T" },
        ]}
        benefits={[
          "Complete market visibility across all EU member states",
          "Real-time updates within hours of publication",
          "Automatic translation and semantic understanding",
          "No need to create accounts on individual portals",
        ]}
        image="/europe-portal-nodes-coverage.jpg"
      />

      <ProductFeatureSection
        id="semantic-matching"
        title="Semantic AI Matching"
        subtitle="Context, Not Just Keywords"
        description="Traditional platforms spam you with irrelevant matches. Our semantic AI understands meaning and context—matching 'intelligent LED infrastructure' with your 'smart street lighting' expertise. Trained on 30 years of procurement data, it delivers 90%+ relevance and learns your preferences over time."
        highlights={[
          { label: "Relevance Rate", value: "90%+" },
          { label: "False Positives", value: "-85%" },
          { label: "Training Data", value: "30 Years" },
          { label: "Time Saved", value: "20hrs/mo" },
        ]}
        benefits={[
          "Only see opportunities you can actually win",
          "No more keyword noise or missed synonyms",
          "Industry-specific intelligence across all sectors",
          "Continuous learning adapts to your preferences",
        ]}
        image="/ai-neural-network-matching.jpg"
        reversed
      />

      <ProductFeatureSection
        id="gap-analysis"
        title="Deep Gap Analysis"
        subtitle="Know Your Chances Before You Start"
        description="Our AI reads entire tender documents and compares them against your capabilities in minutes. Get a detailed match score, traffic-light requirement analysis, and consortium recommendations. See exactly what you can deliver, what's missing, and whether it's worth pursuing—before investing hours in a proposal."
        highlights={[
          { label: "Analysis Time", value: "2 min" },
          { label: "Match Accuracy", value: "95%" },
          { label: "Time Saved", value: "4.5hrs" },
          { label: "Win Rate", value: "+40%" },
        ]}
        benefits={[
          "Multi-dimensional analysis: technical, certifications, geography, capacity",
          "Clear go/no-go recommendations with win probability",
          "Automatic consortium partner suggestions for gaps",
          "Stop wasting time on tenders you can't win",
        ]}
        image="/gap-analysis-interface-checkmarks.jpg"
      />

      <ProductFeatureSection
        id="ai-monitoring"
        title="24/7 AI Monitoring"
        subtitle="Never Miss a Deadline or Opportunity"
        description="While you sleep, our AI scans all 2,000+ portals continuously. Smart notifications deliver only pre-analyzed, high-match opportunities directly to email, Slack, or mobile. Deadline reminders, status updates, and market intelligence keep you ahead of competitors who check manually."
        highlights={[
          { label: "Monitoring", value: "24/7" },
          { label: "Discovery Time", value: "<6hrs" },
          { label: "Alert Relevance", value: "90%" },
          { label: "Noise Reduction", value: "95%" },
        ]}
        benefits={[
          "Continuous scanning with zero manual effort",
          "Customizable alert thresholds and delivery channels",
          "Proactive deadline and status change notifications",
          "First-mover advantage with early discovery",
        ]}
        image="/dashboard-multiple-tools.jpg"
        reversed
      />

      {/* company.match Features */}
      <div className="py-16 bg-slate-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="text-blue-600 font-bold tracking-[0.3em] uppercase text-[10px] mb-4 block">
            Company.Match Ecosystem
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6 tracking-tight">
            Find Perfect Partners in Minutes
          </h2>
          <p className="text-xl text-slate-600 leading-relaxed">
            Turn complex tenders into collaborative wins with AI-powered consortium building
          </p>
        </div>
      </div>

      <ProductFeatureSection
        id="company-database"
        title="10M+ European Companies"
        subtitle="The Most Comprehensive B2G Database"
        description="Built from 30 years of actual tender outcomes, trade registers, company websites, and real-time intelligence. Not just a directory—an intelligent knowledge base showing who can deliver what, where, and how reliably. Find specialized partners you never knew existed."
        highlights={[
          { label: "Companies", value: "10M+" },
          { label: "Data Sources", value: "4 Layers" },
          { label: "History", value: "30 Years" },
          { label: "Coverage", value: "EU-Wide" },
        ]}
        benefits={[
          "Verified tender participation history and outcomes",
          "Detailed capability profiles with certifications",
          "Geographic coverage and operational capacity data",
          "Real-time updates and website-derived intelligence",
        ]}
        image="/european-company-database-network.jpg"
      />

      <ProductFeatureSection
        id="partner-matching"
        title="AI-Powered Partner Matching"
        subtitle="Perfect Consortiums, Automated"
        description="Our AI analyzes capability complementarity, proven track records, geographic fit, and consortium history to suggest ideal partners. What used to take weeks of networking now happens in minutes—with better results. Win tenders worth millions by partnering with the right companies."
        highlights={[
          { label: "Match Time", value: "<5 min" },
          { label: "Partner Accuracy", value: "85%" },
          { label: "Success Rate", value: "+60%" },
          { label: "Avg. Tender Value", value: "€2.5M+" },
        ]}
        benefits={[
          "Complementary capability analysis for optimal fit",
          "Geographic and certification compatibility checking",
          "Historical consortium success rate insights",
          "Direct contact information and introduction support",
        ]}
        image="/ai-matching-algorithm-visualization.jpg"
        reversed
      />

      <ProductFeatureSection
        id="gap-coverage"
        title="Smart Gap Coverage"
        subtitle="Turn 'We Can't' Into 'We Found a Partner'"
        description="When gap analysis shows you're missing capabilities, our AI automatically identifies partners who can close those exact gaps. See which certifications, geographic presence, or technical expertise you need—and who has them. Build winning consortiums based on data, not guesswork."
        highlights={[
          { label: "Gap Closure Time", value: "<10min" },
          { label: "Partner Suggestions", value: "3-5" },
          { label: "Compatibility Score", value: "90%+" },
          { label: "Success Rate", value: "75%" },
        ]}
        benefits={[
          "Automatic partner suggestions for each identified gap",
          "Ranked by compatibility, reliability, and consortium experience",
          "See exactly how each partner complements your capabilities",
          "Contact details and introduction support included",
        ]}
        image="/gap-analysis-interface-with-solutions.jpg"
      />

      <ProductFeatureSection
        id="track-record"
        title="Proven Track Records"
        subtitle="Partner With Confidence"
        description="Don't rely on marketing claims. See actual tender success rates, reliability scores, and sector expertise based on 30 years of real outcomes. Know which companies consistently deliver, which sectors they excel in, and how they've performed in past consortiums. Make data-driven partnership decisions."
        highlights={[
          { label: "Historical Data", value: "30 Years" },
          { label: "Tender Outcomes", value: "Millions" },
          { label: "Reliability Score", value: "0-100" },
          { label: "Sector Analysis", value: "All" },
        ]}
        benefits={[
          "Actual win rates and project completion history",
          "Consortium performance and collaboration ratings",
          "Sector-specific expertise verification",
          "Financial stability and capacity indicators",
        ]}
        image="/track-record-performance-dashboard.jpg"
        reversed
      />

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-br from-blue-600 to-blue-700">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">Ready to Transform Your Procurement?</h2>
          <p className="text-xl text-blue-100 mb-8 leading-relaxed">
            Join hundreds of companies winning more tenders with less effort
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-blue-600 px-8 py-4 rounded-xl font-bold hover:bg-blue-50 transition-colors">
              Start Free Trial
            </button>
            <button className="bg-blue-500 text-white px-8 py-4 rounded-xl font-bold hover:bg-blue-400 transition-colors border-2 border-blue-400">
              Book a Demo
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
